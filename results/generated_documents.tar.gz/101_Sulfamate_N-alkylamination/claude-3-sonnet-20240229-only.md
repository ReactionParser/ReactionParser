Here is a draft Wikipedia-like article on sulfamate N-alkylamination:

Sulfamate N-Alkylamination

Sulfamate N-alkylamination is an organic reaction that involves the alkylation of a sulfamate anion with an alkyl halide. It allows for the introduction of an alkyl group onto a nitrogen atom attached to a sulfamate functional group.

Reaction Mechanism
The sulfamate N-alkylamination reaction proceeds via an SN2 mechanism. First, the sulfamate anion acts as a nucleophile and attacks the alkyl halide electrophile, displacing the halide leaving group. This forms a new carbon-nitrogen bond between the alkyl group and the sulfamate nitrogen.

The overall reaction is:

RSO2NNa + R'X → RSO2NR' + NaX

Where R is an organic group attached to the sulfamate, R' is the alkyl group being introduced, and X is a halide leaving group like chloride or bromide.

Synthetic Applications
This reaction is useful for installing alkyl groups onto sulfamate nitrogens. The sulfamate group can then act as a robust nitrogen protecting group that is stable to many reaction conditions. It can later be removed under strongly acidic conditions.

N-Alkylated sulfamates are also valuable synthetic intermediates themselves. The sulfamate group can be converted into other nitrogen-containing functional groups like amines, amides, ureas, and sulfonamides through various transformations.

Limitations
The alkyl halide electrophile must be primary for the SN2 reaction to occur efficiently. Secondary and tertiary alkyl halides are poor substrates due to steric hindrance. Strong bases are required to generate the sulfamate anion nucleophile.

Overall, sulfamate N-alkylamination provides a straightforward way to alkylate sulfamate nitrogen atoms using readily available alkyl halide reagents under basic conditions.