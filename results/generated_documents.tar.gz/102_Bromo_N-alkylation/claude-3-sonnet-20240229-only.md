Here is a draft Wikipedia-like article on bromo N-alkylation:

Bromo N-Alkylation

Bromo N-alkylation is an organic reaction used to introduce an alkyl group onto a nitrogen atom. It involves the reaction of an amine with an alkyl bromide under basic conditions. This substitution reaction forms a new carbon-nitrogen bond.

Reaction Mechanism
The bromo N-alkylation proceeds via an SN2 mechanism. First, the amine acts as a nucleophile and attacks the alkyl bromide electrophile, displacing the bromide leaving group. This forms a transient tetrahedral intermediate. The negatively charged bromide ion then removes a proton from the intermediate to give the substituted N-alkylated product and hydrogen bromide (HBr) as the byproduct.

The reaction requires a strong non-nucleophilic base like sodium hydride (NaH) or potassium tert-butoxide (t-BuOK) to deprotonate the amine, making it a better nucleophile. Polar aprotic solvents like DMF or THF are typically used.

Limitations
Steric hindrance around the amine can slow or prevent the reaction. Tertiary amines cannot undergo N-alkylation. The alkyl bromide must be primary or non-hindered for the SN2 reaction to occur efficiently. Alkyl iodides and alkyl chlorides can also be used but are less reactive.

Applications
Bromo N-alkylation is a key step in the synthesis of many nitrogen-containing organic compounds and pharmaceuticals. It introduces alkyl groups onto amines, amides, heterocycles, and other nitrogen-based functional groups. The alkylated products have different chemical properties than the starting amine.