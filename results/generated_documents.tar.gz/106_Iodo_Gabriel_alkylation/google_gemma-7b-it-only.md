## Iodo Gabriel Alkylation

Iodo Gabriel alkylation is a chemical reaction that converts amines to iodinated amines using N-iodosuccinimide (NIS) and sodium methoxide or ethoxide. The reaction is named after the chemist Otto Diels, who first reported it in 1928.

**Mechanism:**

The Iodo Gabriel alkylation reaction is based on the following mechanism:

1. **Formation of the nucleophilic amine:** Sodium methoxide or ethoxide deprotonates the amine, creating a nucleophilic amine.
2. **Nucleophilic substitution:** The nucleophilic amine attacks the iodine atom on NIS, displacing a halide ion.
3. **Iodination:** The halide ion is replaced by the amine, forming the iodinated amine.

**Reaction conditions:**

* The reaction is carried out in a solvent such as dimethylformamide (DMF) or tetraethylene glycol (TEG).
* The reaction temperature is typically between 0 and 50 °C.
* The reaction time is typically between 15 minutes and several hours.

**Reagents:**

* Amine
* N-iodosuccinimide (NIS)
* Sodium methoxide or ethoxide
* Solvent (e.g., DMF, TEG)

**Products:**

* Iodinated amine
* Sodium iodide
* NIS byproduct

**Uses:**

Iodo Gabriel alkylation is a versatile reaction that is used to iodinate a wide variety of amines. It is commonly used in the synthesis of iodinated compounds, which have a wide range of applications in medicine, chemistry, and materials science. For example, iodinated amines are used to:

* Label amines for protein and DNA biochemistry
* Create iodinated pharmaceuticals
* Manufacture dyes and pigments
* Synthesize other iodinated compounds

**Variations:**

There are a number of variations of the Iodo Gabriel alkylation reaction, including:

* **Iodo Gabriel guanidination:** This reaction converts guanidines to iodinated guanidines.
* **Iodo Gabriel tosylation:** This reaction converts amines to iodinated tosylates.
* **Iodo Gabriel halogenation:** This reaction converts amines to iodinated amines using other halides (e.g., bromide, chloride).

**Safety:**

The Iodo Gabriel alkylation reaction is generally considered to be safe, but there are some precautions that should be taken. These include:

* Wearing gloves and eye protection
* Using a fume hood to ventilate the reaction mixture
* Avoiding contact with skin and eyes
* Heating the reaction mixture slowly and carefully
* Disposing of the reaction waste properly