Here is a draft Wikipedia-like article on iodo N-alkylation:

Iodo N-Alkylation

Iodo N-alkylation is an organic reaction used to alkylate nitrogen-containing compounds like amines and amides. It involves the use of an alkyl iodide as the alkylating agent along with a base.

Reaction Mechanism
The iodo N-alkylation reaction proceeds via an SN2 mechanism. First, the nitrogen atom on the amine/amide uses its lone pair of electrons to deprotonate the base, forming an amide ion intermediate. This nucleophilic amide ion then performs an SN2 attack on the alkyl iodide, displacing the iodide leaving group and forming the N-alkylated product.

The reaction is facilitated by polar aprotic solvents like DMF or acetonitrile that can stabilize the charged intermediates and transition states. Common bases used include sodium hydride, potassium tert-butoxide, or hindered amines like diisopropylethylamine.

Advantages
- Alkyl iodides are relatively inexpensive and readily available alkylating agents
- The reaction can be performed under mild conditions
- Iodide is a good leaving group facilitating the SN2 displacement

Limitations
- The reaction requires an unhindered amine/amide substrate to allow SN2 attack
- Alkyl iodides can undergo elimination side reactions under basic conditions
- The reaction is moisture sensitive due to the basic conditions

Applications
Iodo N-alkylation is a useful method for the N-alkylation of amines, amides, heterocycles, and other nitrogen-containing compounds. It is commonly used in pharmaceutical, agrochemical, and materials science synthesis when installing alkyl groups onto nitrogen atoms.